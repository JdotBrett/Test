/*    ==Scripting Parameters==

    Source Server Version : SQL Server 2016 (13.0.4001)
    Source Database Engine Edition : Microsoft SQL Server Express Edition
    Source Database Engine Type : Standalone SQL Server

    Target Server Version : SQL Server 2016
    Target Database Engine Edition : Microsoft SQL Server Express Edition
    Target Database Engine Type : Standalone SQL Server
*/

USE [Clients]
GO

/****** Object:  StoredProcedure [dbo].[GetClient]    Script Date: 10/10/2017 14:07:05 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[GetClient] @ClientId INT

AS
BEGIN
SELECT 
	ClientId,
	ClientName,
	ClientAddress,
	ClientTelephone,
	ClientEmail,
	ClientFax,
	ClientData.StatusId,
	Status.StatusState

 FROM ClientData 
INNER JOIN Status on Status.StatusId = ClientData.StatusId
WHERE ClientId = @ClientId
END
GO

