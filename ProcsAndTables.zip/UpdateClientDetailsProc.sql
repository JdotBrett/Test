/*    ==Scripting Parameters==

    Source Server Version : SQL Server 2016 (13.0.4001)
    Source Database Engine Edition : Microsoft SQL Server Express Edition
    Source Database Engine Type : Standalone SQL Server

    Target Server Version : SQL Server 2016
    Target Database Engine Edition : Microsoft SQL Server Express Edition
    Target Database Engine Type : Standalone SQL Server
*/

USE [Clients]
GO

/****** Object:  StoredProcedure [dbo].[UpdateClientDetails]    Script Date: 10/10/2017 14:07:31 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[UpdateClientDetails] @ClientId INT, @ClientName VARCHAR(50), @ClientAddress VARCHAR(max), @ClientTelephone VARCHAR(12), @ClientFax VARCHAR(50) = NULL, @ClientEmail VARCHAR(50), @StatusId INT

AS
BEGIN
UPDATE ClientData 
SET ClientName = @ClientName, ClientAddress = @ClientAddress, ClientTelephone = @ClientTelephone, ClientFax = @ClientFax, ClientEmail = @ClientEmail, StatusId = @StatusId
WHERE ClientId = @ClientId
END
GO

